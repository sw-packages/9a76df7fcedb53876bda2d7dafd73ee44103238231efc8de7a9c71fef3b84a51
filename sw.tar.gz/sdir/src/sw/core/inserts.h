// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2019-2020 Egor Pugin <egor.pugin@gmail.com>

#include <string>

extern const std::string inputs_db_schema;
extern const std::string html_template_build;
extern const std::string render_py;
